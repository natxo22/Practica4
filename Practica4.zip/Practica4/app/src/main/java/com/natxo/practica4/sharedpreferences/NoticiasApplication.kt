package com.natxo.practica4.sharedpreferences

import android.app.Application

class NoticiasApplication: Application() {

    companion object{
        lateinit var prefs: Prefs
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(applicationContext)
    }
}