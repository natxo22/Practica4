package com.natxo.practica4

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.natxo.practica4.databinding.ActivityAddNoticiaBinding

class AddNoticiaActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddNoticiaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityAddNoticiaBinding.inflate(layoutInflater)
        setContentView(binding.root)



    }
}