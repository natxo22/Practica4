package com.natxo.practica4.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.natxo.practica4.dao.*
import com.natxo.practica4.entity.*

@Database(entities = [NoticiaEntity::class, UsuarioEntity::class, FavoritoEntity::class],
    version = 1)
abstract class Practica4: RoomDatabase() {
    abstract fun noticiaDao(): NoticiaDao
    abstract fun usuarioDao(): UsuarioDao
    abstract fun favoritoDao(): FavoritoDao
}
